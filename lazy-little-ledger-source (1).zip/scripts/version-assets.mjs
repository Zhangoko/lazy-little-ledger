
import {readFile,writeFile,readdir,unlink} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const names=['app.js','views.js','model.js','export.js','motion.js','style.css','theme.css','motion.css','fonts.css'];
const sources=new Map(await Promise.all(names.map(async n=>[n,await readFile('dist/'+n,'utf8')])));
const hash=createHash('sha256').update([...sources].map(([n,c])=>n+'\n'+c).join('\n')).digest('hex').slice(0,12);
const versioned=n=>n.replace(/\.(js|css)$/,'.'+hash+'.$1');
for(const n of await readdir('dist'))if(/^[a-z]+\.[a-f0-9]{12}\.(?:js|css)$/.test(n))await unlink('dist/'+n);
for(const [name,source] of sources){let text=source.replace(/(['"])\.\/([a-z]+\.js)\1/g,(all,q,n)=>sources.has(n)?q+'./'+versioned(n)+q:all);
 if(name==='style.css')text=text.replace('url("fonts.css")','url("'+versioned('fonts.css')+'")');
 await writeFile('dist/'+versioned(name),text);
}
let html=await readFile('dist/index.html','utf8');
for(const n of ['app.js','style.css','theme.css','motion.css']){const [stem,ext]=n.split('.');html=html.replace(new RegExp('(src|href)="'+stem+'(?:\\.[a-f0-9]{12})?\\.'+ext+'(?:\\?[^"]*)?"','g'),(a,attr)=>attr+'="'+versioned(n)+'"');}
html=html.replace(/<meta name="app-build"[^>]*>/,'').replace('<head>','<head><meta name="app-build" content="'+hash+'">');
await writeFile('dist/index.html',html);
console.log('Versioned assets ready: '+hash);
