import test from 'node:test';
import assert from 'node:assert/strict';
import {fresh,demo,parseMoney,balance,totals,upsert,removeRecord,validateBackup,exportRows,csv,currentMonth,calculateCents,addReferenceCategories} from '../dist/model.js';
import {filtered,exportRecords,renderView} from '../dist/views.js';
import {xlsx} from '../dist/export.js';
const sample=(extra={})=>({type:'expense',cents:1234,bookId:'daily',accountId:'wechat',catId:'meal',date:currentMonth()+'-02T12:00',note:'测试午餐',...extra});
test('amounts use exact integer cents and reject unsupported input',()=>{
 assert.equal(parseMoney('0.29'),29);assert.equal(parseMoney('1,234.50'),123450);assert.equal(parseMoney('-1.25',true),-125);
 for(const v of ['-1','1.234','NaN','Infinity','','1e2'])assert.throws(()=>parseMoney(v));
});
test('explicit demo totals agree with account balances',()=>{
 const d=demo(),t=totals(d,'daily',currentMonth());assert.equal(t.expense,236850);assert.equal(t.income,850000);assert.equal(t.count,46);
 assert.deepEqual(d.accounts.map(a=>balance(d,a.id)),[131250,48000,1050000,12000]);
 assert.equal(d.accounts.reduce((s,a)=>s+balance(d,a.id),0),1241250);
});
test('edit and delete recalculate balance once and preserve history',()=>{
 const d=fresh();let r=upsert(d,sample());assert.equal(balance(d,'wechat'),-1234);
 r=upsert(d,{...r,cents:1000});assert.equal(d.records.length,1);assert.equal(balance(d,'wechat'),-1000);
 assert.equal(totals(d,'daily',currentMonth()).expense,1000);assert.equal(d.audit[1].before.cents,1234);
 removeRecord(d,r.id);assert.equal(balance(d,'wechat'),0);assert.equal(d.audit.at(-1).action,'delete');
});
test('transfers change two balances but never income or expense',()=>{
 const d=fresh();d.accounts[2].initial=100000;
 upsert(d,sample({type:'transfer',cents:5000,accountId:'bank',toAccountId:'wechat',catId:undefined}));
 assert.equal(balance(d,'bank'),95000);assert.equal(balance(d,'wechat'),5000);
 assert.deepEqual(totals(d,'daily',currentMonth()),{income:0,expense:0,count:0,cats:{}});
 assert.throws(()=>upsert(d,sample({type:'transfer',toAccountId:'wechat'})));
 assert.throws(()=>upsert(d,sample({catId:'salary'})));
});
test('backup roundtrip preserves records; broken references are refused',()=>{
 const d=demo(),copy=validateBackup(JSON.parse(JSON.stringify(d)));assert.deepEqual(copy,JSON.parse(JSON.stringify(d)));
 copy.records[0].accountId='missing';assert.throws(()=>validateBackup(copy));
 const duplicate=fresh();duplicate.books.push({...duplicate.books[0]});assert.throws(()=>validateBackup(duplicate));
});
test('explicit date range filters across months and export matches',()=>{
 const d=fresh();upsert(d,sample({date:'2026-09-30T12:00'}));upsert(d,sample({date:'2026-10-02T12:00'}));
 const ui={bookId:'daily',month:'2026-10',filters:{start:'2026-09-01',end:'2026-09-30'}};
 assert.equal(filtered(d,ui).length,1);assert.equal(filtered(d,ui)[0].date,'2026-09-30T12:00');
 assert.equal(exportRecords(d,{...ui,export:{start:'2026-09-01',end:'2026-10-31'}}).length,2);
});
test('CSV escapes quotes and protects spreadsheet formulas',()=>{
 const s=csv([['=HYPERLINK("x")','午餐,咖啡',12.34]]);assert.ok(s.startsWith('\uFEFF'));assert.ok(s.includes("'=HYPERLINK"));assert.ok(s.includes('""x""'));assert.ok(s.includes('"12.34"'));
});
test('Excel is a zipped workbook with proper media type',async()=>{
 const blob=xlsx(exportRows(demo(),demo().records));assert.equal(blob.type,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
 const bytes=new Uint8Array(await blob.arrayBuffer());assert.deepEqual([...bytes.slice(0,4)],[80,75,3,4]);
});
test('all routes render for a fresh and sample ledger, with escaped notes',()=>{
 for(const d of [fresh(),demo()]){
 const ui={route:'home',bookId:'daily',month:currentMonth(),form:{type:'expense',amount:'',date:currentMonth()+'-01T12:00',accountId:'wechat',bookId:'daily',catId:'meal',note:'<script>'},filters:{},export:{},catType:'expense',accountId:'wechat',recordId:d.records[0]?.id};
 for(const route of ['home','bills','filter','entry','detail','review','budget','budgetEdit','accounts','accountDetail','accountAdd','books','bookAdd','categories','profile','settings','export','reminder','welcome','success']){
  assert.ok(renderView(d,{...ui,route}).includes('class="layout"'),route);
 }
 assert.ok(!renderView(d,{...ui,route:'entry'}).includes('<script>'));
 }
});

test('keypad adds and subtracts exact cents without floating point',()=>{
 assert.equal(calculateCents(3200,29,'+'),3229);assert.equal(calculateCents(3229,234,'-'),2995);
 assert.throws(()=>calculateCents(100,101,'-'));assert.throws(()=>calculateCents(1,1,'*'));
});
test('reference category update preserves custom categories and runs once',()=>{
 const d=fresh();d.categories.push({id:'pet',name:'猫咪',type:'expense',icon:'gift'});addReferenceCategories(d);
 assert.equal(d.categories.filter(c=>c.type==='expense').length,12);assert.ok(d.categories.some(c=>c.id==='pet'));
 d.categories=d.categories.filter(c=>c.id!=='travel');addReferenceCategories(d);assert.ok(!d.categories.some(c=>c.id==='travel'));
});
